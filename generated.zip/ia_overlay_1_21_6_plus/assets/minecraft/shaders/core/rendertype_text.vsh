#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_6b0ec5ef(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_a53db47d() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_f5fd6c57(inout vec4 vertex) {
    f_6b0ec5ef(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_a53db47d();
    }
    finalize();
}



void f_758cd58b() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_d9e1a4bf() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_f3eee5c6(inout vec4 vertex) {
    f_6b0ec5ef(vertex);
    f_758cd58b();
    finalize();
}

void f_b8c9ec36(inout vec4 vertex) {
    f_6b0ec5ef(vertex);
    f_a53db47d();
    f_d9e1a4bf();
    finalize();
}

void f_4a77b42d(inout vec4 vertex) {
    f_6b0ec5ef(vertex);
    f_d9e1a4bf();
    f_758cd58b();
    finalize();
}

void f_46a59e93(inout vec4 vertex) {
    f_a53db47d();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_6b0ec5ef(vertex);
    finalize();
}

void f_1dca7dac(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_758cd58b();
    f_6b0ec5ef(vertex);
    finalize();
}

void f_3b5e4091(inout vec4 vertex, float speed) {
    f_6b0ec5ef(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_7795c8f4(inout vec4 vertex) {
    f_6b0ec5ef(vertex);
    f_a53db47d();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_f5fd6c57(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_a53db47d();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_6b0ec5ef(vertex);
            f_a53db47d();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_b8c9ec36(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_b8c9ec36(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_46a59e93(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_46a59e93(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_3b5e4091(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_7795c8f4(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_f3eee5c6(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_b8c9ec36(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_4a77b42d(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_46a59e93(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_1dca7dac(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_3b5e4091(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_f3eee5c6(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_b8c9ec36(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_4a77b42d(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_46a59e93(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_1dca7dac(vertex);
        return;
    }
    

    
    f_6b0ec5ef(vertex);
    f_a53db47d();
    finalize();
}